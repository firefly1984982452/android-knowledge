package com.firefly.common;

/**
 * Created by pengdan on 2016/6/28.
 */
public class Constant {
    public final static String OPEN_ID = "wx96502e503af457e7";
    public final static String SW_ID = "1268956301";
    public final static String API_KEY = "stylestylestylestylewenjiao82112";
    public final static String ORDER="https://api.mch.weixin.qq.com/pay/unifiedorder";
}
